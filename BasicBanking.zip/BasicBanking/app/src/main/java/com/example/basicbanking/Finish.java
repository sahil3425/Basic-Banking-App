package com.example.basicbanking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class Finish extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finish);new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(Finish.this, Users.class));
                finish();
            }
        },3000);
    }
}