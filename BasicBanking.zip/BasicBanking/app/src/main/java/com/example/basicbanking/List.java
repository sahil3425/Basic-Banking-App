package com.example.basicbanking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class List extends AppCompatActivity {
    Helper helper;
    ListView listView;
    String Total, Name;
    Cursor data;
    String Price;
    ArrayList<String> arrayList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_list);
        helper = new Helper(this);
        listView = findViewById(R.id.listview);

        populateList();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Total = arrayList.get(position);
                Price = Total.substring(Total.indexOf("com") + 4, Total.length() - 1);
                Name = Total.substring(0, Total.indexOf("\n"));
//                PreviousAmount=Integer.parseInt(Price);
                Intent intent = new Intent(List.this, amount.class);
                try {
                    intent.putExtra("price", Integer.parseInt(Price));
                    intent.putExtra("name", Name);
                } catch (NumberFormatException e) {
                    Toast.makeText(List.this, "Failed", Toast.LENGTH_SHORT).show();
                }

                startActivity(intent);

            }
        });
    }

    private void populateList() {
        data = helper.getData();
        arrayList = new ArrayList<>();
        while (data.moveToNext()) {
            arrayList.add(data.getString(1) + "\n" + data.getString(2) + "\n" + data.getString(3) + "\n");
        }
        ListAdapter listAdapter = new ArrayAdapter<>(this, R.layout.row1, arrayList);
        listView.setAdapter(listAdapter);
    }
}