package com.example.basicbanking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class amount extends AppCompatActivity {
    ArrayList<String> arrayList;
    Helper helper;
    TextView SenderName, ReceiveName;
    ListView listView1;
    Button send;
    String senderAmount;
    String Total, Price, receiveName, senderName;
    int previous;
    EditText amount;
    Cursor data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amount);
        helper = new Helper(this);
        listView1 = findViewById(R.id.listview2);
        send = findViewById(R.id.button3);
        SenderName = findViewById(R.id.SenderName);
        ReceiveName = findViewById(R.id.recieveName);
        amount = findViewById(R.id.amountSend);
        Intent intent = getIntent();
        SenderName.setText("@" + intent.getStringExtra("name"));
        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Total = arrayList.get(position);
                receiveName = Total.substring(0, Total.indexOf("\n"));
                Price = Total.substring(Total.indexOf("com") + 4, Total.length() - 1);
                Toast.makeText(com.example.basicbanking.amount.this, receiveName, Toast.LENGTH_SHORT).show();
                boolean recieved = helper.updateData(receiveName, (Integer.parseInt(senderAmount) + Integer.parseInt(Price)));
                boolean sender = helper.updateData(senderName, previous - Integer.parseInt(senderAmount));
                if (recieved && sender) {
                    Toast.makeText(com.example.basicbanking.amount.this, "done", Toast.LENGTH_SHORT).show();
                    populateList();
                    startActivity(new Intent(com.example.basicbanking.amount.this, Finish.class));
                    finish();
                } else {
                    Toast.makeText(com.example.basicbanking.amount.this, "failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void SenderActivity(View view) {
        senderAmount = amount.getText().toString();
        Intent intent = getIntent();
        previous = intent.getIntExtra("price", 0);
        senderName = intent.getStringExtra("name");
        if (previous < Integer.parseInt(senderAmount)) {
            Toast.makeText(com.example.basicbanking.amount.this, "insufficient Amount", Toast.LENGTH_SHORT).show();
        } else {
            listView1.setVisibility(View.VISIBLE);
            amount.setVisibility(View.INVISIBLE);
            SenderName.setVisibility(View.INVISIBLE);
            ReceiveName.setVisibility(View.VISIBLE);
            send.setVisibility(View.INVISIBLE);
            populateList();
        }
    }

    private void populateList() {
        data = helper.getData();
        arrayList = new ArrayList<>();
        while (data.moveToNext()) {
            if((data.getString(1).equals(senderName))){
                continue;
            }
            else{
            arrayList.add(data.getString(1) + "\n" + data.getString(2) + "\n" + data.getString(3) + "\n");
        }
        }
        ListAdapter listAdapter = new ArrayAdapter<>(this, R.layout.row, arrayList);
        listView1.setAdapter(listAdapter);
    }
}