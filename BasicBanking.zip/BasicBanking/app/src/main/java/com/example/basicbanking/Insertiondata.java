package com.example.basicbanking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class Insertiondata extends AppCompatActivity {
    EditText name, Email, Amount;
    String Name;
    String email;
    int currentAmount;
    Helper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insertiondata);
        helper = new Helper(this);
        name = findViewById(R.id.UserName);
        Email = findViewById(R.id.emailUser);
        Amount = findViewById(R.id.numberUser);


    }

    public void InsertData(View view) {
        Name = name.getText().toString();
        email = Email.getText().toString();
        currentAmount = Integer.parseInt(Amount.getText().toString());
        boolean insert = helper.insertData(Name, email, currentAmount);
        if (insert) {
            Toast.makeText(this, "dataAdded", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, List.class));
        } else {
            Toast.makeText(this, "failed", Toast.LENGTH_SHORT).show();
        }

    }
}