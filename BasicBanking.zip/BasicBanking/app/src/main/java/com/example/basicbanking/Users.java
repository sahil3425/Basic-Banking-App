package com.example.basicbanking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


public class Users extends AppCompatActivity {
    Button button4,button3;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_acivity);

        button3 = findViewById(R.id.button3);
        button4=findViewById(R.id.button4);
        imageView=findViewById(R.id.imageView);
        imageView.setImageResource(R.drawable.des);

    }



    public void AddData(View view) {
     startActivity(new Intent(Users.this,Insertiondata.class));


    }

    public void PayNow(View view) {
        startActivity(new Intent(Users.this, List.class));

    }
}