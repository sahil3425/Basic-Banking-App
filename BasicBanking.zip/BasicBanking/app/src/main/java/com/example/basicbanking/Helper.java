package com.example.basicbanking;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Helper extends SQLiteOpenHelper {
    public Helper(@Nullable Context context) {
        super(context, "userdata.db", null, 3);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query="CREATE TABLE userdata(ID INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT , email TEXT , currentAmount INT)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop Table if exists userdata");
    }

    public Boolean insertData(String name, String email, Integer currentAmount) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("email", email);
        contentValues.put("currentAmount", currentAmount);
        long result = database.insert("userdata", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }

    }

    public Boolean updateData(String name,Integer currentAmount) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("currentAmount", currentAmount);
        Cursor cursor = database.rawQuery("Select * from userdata where name=?", new String[]{name});
        if (cursor.getCount() > 0) {
            long result = database.update("userdata", contentValues, "name=?", new String[]{name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
public Cursor getData(){
        SQLiteDatabase database=this.getWritableDatabase();
         String query="SELECT * FROM userdata";
        Cursor data=database.rawQuery(query,null);
        return data;
}

}
